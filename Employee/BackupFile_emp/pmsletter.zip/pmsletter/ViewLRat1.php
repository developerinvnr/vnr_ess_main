Your performance for the assessment period <b><?php echo $Ass2Year; ?></b> has been rated as <?php if($ResE['DepartmentId']==2 AND $resG['GradeValue']!='L1' AND $resG['GradeValue']!='L2' AND $resG['GradeValue']!='L3' AND $resG['GradeValue']!='L4' AND $resG['GradeValue']!='L5' AND $resG['GradeValue']!='MG'){ ?>"<b>1</b>". The given rating is based on Individual performance, Group performance and Departmental performance.<?php }else{ ?><b>"<?php echo $ResR['RatingName']; ?>"</b> with "<b>Rating-1</b>".<?php } ?><?php /*?><b>"<?php echo $ResR['RatingName']; ?>"</b> with "<b>Rating-1</b>".<?php */?> <p> 
           Your performance is far below expectations and there is no improvement in your performance despite regular feedback for improvement from your seniors through formal and informal mechanisms.<p>
           We feel that you are not suitable to manage the current profile and should part with the organization for other better career option suiting your strengths. <p>
           We hereby give you one month notice for searching other opportunities and for proper handover of your work to your reporting manager. <p>
		   
		   
		   
		   
		   