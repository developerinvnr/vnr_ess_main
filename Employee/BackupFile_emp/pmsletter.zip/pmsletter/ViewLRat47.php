We are pleased to inform you that your performance for the year <b><?php echo $AssYear; ?></b> has been rated as <?php if($ResE['DepartmentId']==2 AND $resG['GradeValue']!='L1' AND $resG['GradeValue']!='L2' AND $resG['GradeValue']!='L3' AND $resG['GradeValue']!='L4' AND $resG['GradeValue']!='L5' AND $resG['GradeValue']!='MG'){ ?>"<b>4.7</b>". The given rating is based on Individual performance, Group performance and Departmental performance.<?php }else{ ?><b>"<?php echo $ResR['RatingName']; ?>"</b> with "<b>Rating-4.7</b>".<?php } ?><?php /*?><b>"<?php echo $ResR['RatingName']; ?>"</b> with "<b>Rating-4.7</b>".<?php */?> <p>   

           We appreciate your valuable contribution towards organizational objective achievements and expect you would continue to perform with greater sense of diligence & responsibility. We look forward to you being a role model for your peers and subordinates to emulate. <p>

           Based on your performance, there is an increase in your CTC by <b>Rs. <?php echo floatval($ResPMS['HR_IncNetCTC']); ?>/- </b>.<?php if($_REQUEST['C']==1 AND $ResE['DateJoining']>=$FD2.'-01-01' AND $ResE['DateJoining']<=$FD2.'-06-30') { ?> As your service is less than a year in the assessment cycle <?php echo $AssYear; ?>, your increment is calculated on pro-rata basis as per the duration served during this period against the actual increment of <b><?php echo intval(($ResPMS['EmpCurrCtc']*$resMaxMin['IncDistriFrom'])/100); //floatval($ResPMS['HR_IncNetCTC']); ?>/-</b> as per your performance rating.<p><?php } ?><?php if($_REQUEST['C']==1 AND $ResE['DateJoining']>=$FD1.'-07-01' AND $ResE['DateJoining']<=$FD1.'-12-31') { ?> As your assessment tenure is more than a year (DOJ on or after 1st July <?php echo $FD1; ?>), your increment is calculated on pro-rata basis for the duration served since your joining against the actual annual increment for assessment cycle<?php //echo $AssYear; ?> that is <b><?php echo intval(($ResPMS['EmpCurrCtc']*$resMaxMin['IncDistriFrom'])/100); //floatval($ResPMS['HR_IncNetCTC']); ?>/-</b> as per your performance rating.<p><?php } ?>

		   <?php if($ResPMS['HR_ProCorrCTC']>0){ ?>Taking into consideration the industry salary benchmark, we are providing salary correction of <b>Rs. <?php echo floatval($ResPMS['HR_ProCorrCTC']); ?>/- </b> per annum. <?php } ?><p>

           Your CTC is therefore being revised from <b>Rs. <?php echo floatval($ResPMS['EmpCurrCtc']); ?>/- </b> to <b>Rs. <?php echo floatval($ResPMS['HR_Proposed_ActualCTC']); ?>/- </b> with effect from <?php echo $SeteD; ?>.<p>
		   
		   <?php if($ResE['DepartmentId']==6 AND $ResE['EmpVertical']>0){ ?>
           Based on the Sales Function restructuring you are designated as <b><?php echo $resD['DesigName'].' ('.$VerticalName.')';?></b>, HQ as <b><?php echo $rHq['HqName'];?></b> and reporting to <b><?php echo $NameR;?></b>. <p> 
<?php } ?>

           Please find your revised remuneration in Annexure A as an enclosure with this letter along with your Entitlements in Annexure-B. <p>

           <?php if($ResPMS['HR_CurrDesigId']!=$_REQUEST['D'] OR $resGr2['GradeValue']!=$_REQUEST['G']) { ?>
		   We also wish to inform you that to appreciate your exceptional performance and having belief in your competencies to handle higher responsibility & to meet the up-coming challenges, we hereby promote you <?php if($ResPMS['HR_CurrDesigId']!=$_REQUEST['D']) { echo 'as <b>'.$resD['DesigName'].'</b>'; } if($ResPMS['HR_CurrDesigId']!=$_REQUEST['D'] AND $resGr2['GradeValue']!=$_REQUEST['G']) { echo ', '; } if($resGr2['GradeValue']!=$_REQUEST['G']) {?>to Grade <?php echo '<b>'.$resG['GradeValue'].'</b>'; } if($ResPMS['HR_CurrDesigId']!=$_REQUEST['D'] OR $resGr2['GradeValue']!=$_REQUEST['G']) { ?> w.e.f <?php echo $SeteD; ?>. <?php } } ?> <p> 

           We take this opportunity to compliment you and your family for your dedication and commitment to the organization. <p>
