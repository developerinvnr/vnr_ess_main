<?php session_start(); ?>
<html>
<head>
<title><?php include_once('Title.php'); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<link href="css/style.css" rel="stylesheet" type="text/css">
<style>
.text_login
{
width:160px;
size:20px;
height:18px;
}
.text_login1
{
width:130px;
size:15px;
height:18px;
}
</style>
<Script type="text/javascript">window.history.forward(1);</Script>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#FFFFFF">
<center>
<table border="0" style="margin-top:20px;margin-bottom:20px;margin-left:20px;margin-right:20px;width:550px;height:550px;" align="center" cellpadding="2" cellspacing="0">
  <tr>
   <td>
    <table border="0" style="width:550px;height:500px;" cellpadding="0" cellspacing="0">
	 <tr style="height:22px; background-color:#B0FB4D;background-image:url(../images/b1.jpg);">
	  <td colspan="2" style="width:550px;" valign="bottom">&nbsp;</td>

	 </tr>
	 <tr style="height:15px; background-color:#FFFFFF;">
	  <td colspan="2" style="width:550px;" align="right" valign="bottom"></td>
	 </tr>
	 <tr style="height:22px;">
	  <td style="background-color:#666699;text-align:center; vertical-align:middle;">
	  </td> 
<?php /////////////// Open ?>	 
	  <td rowspan="2" style="width:520px;background-color:#666699;" valign="top">
	  
<table border="0" style="height:200px;margin-top:100px;width:810px;">
<tr>	
  <td id="ContactCell" style="display:none;" valign="top" style="width:500px;">
	<td><?php require_once("unset.php"); ?><br><br><br><br><br><br><br><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="index.php" alt="ESS" style="text-shadow:#DAE40E;color:#00FFFF;font-family:Times New Roman;font-size:20px;text-shadow:1px 1px 2px #24740A;text-decoration:none;"><b>Go to Login Panel</b>&nbsp;&nbsp;
	</td>
  </td>		   		  		  				
</tr>	
</table> 
	  </td>
<?php /////////////// Close ?>
	 </tr>
	 <tr style="height:380px;background-color:#666699;">
	  <td style="text-align:center;color:#FFFFFF;font-size:25px;" valign="top">
	      <br>&nbsp;<br>&nbsp;<br>&nbsp;<br>
	         FA<br>Admin
	  </td>
	 </tr>

     <tr style="background-color:#FFFFFF;">
	  <td colspan="2">
	    <table cellpadding="0" cellspacing="0">
<tr style="height:10px;">
  <td style=" background-color:#FFFFFF;width:1050px;height:10px;" align="center">
    <table style="width:1000px;" border="0" cellspacing="0" cellpadding="0">
     <tr style="height:10px;">
	  <td style="width:400px;background-color:#FFFFFF;"></td>
	  <td style="width:200px;background-color:#FFFFFF;"></td>
	  <td style="width:400px;background-color:#FFFFFF;"></td>
	 </tr> 
    </table>		
  </td>
</tr>

<tr style="height:22px;background-image:url(../images/b1.jpg);"><td>&nbsp;</td></tr>

		</table>
	  </td>
	 </tr>
    </table>
 </td>	
 </tr>
</table>
</center>
</body>
</html>